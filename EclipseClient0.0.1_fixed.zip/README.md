# Eclipse Client NextGen Framework

Client-side Fabric framework targeting Minecraft Java 1.21.11 / Java 21.

## Included
- Annotation-based `@Subscribe` event bus and typed tick/render/motion/block-place/packet event contracts.
- Module manager, categories, keybinds, lifecycle hooks, and basic setting classes.
- `.bind`, `.toggle`, `.modules`, `.schematic load`, `.printer start|stop`, `.save`, `.help`.
- Click GUI, HUD module list, Sprint, FullBright, and AutoPrinter planning scaffold.
- Schematic model and reach-limited missing-block planner.

## Important honest limitations
This is a framework scaffold, not a finished autonomous bot or verified production client.
- `SchematicManager` does **not yet parse** `.litematic`, Sponge `.schem`, or vanilla structure NBT. A native parser must decode NBT palettes, packed block-state arrays and version-specific palette entries.
- Printer engine currently scans/queues target blocks only after a `Schematic` and origin are supplied in code. It does not automatically place blocks, rotate, swap inventory, or send packets.
- `PacketEvent` types are contracts only. Fabric API does not expose all packet interception events directly; version-specific Mixins are needed.
- Render3DEvent and BlockPlaceEvent are event contracts and are not yet wired to mixins/callbacks.
- Dragging windows, editable setting widgets, gradient HUD, TPS/FPS readout, and full ColorSetting UI are follow-up tasks.
- Dependency versions and mappings have not been validated by running a Gradle build in this environment. Check the Fabric Maven repository if a dependency coordinate cannot resolve.

## Build
Use Java 21. From the project root:
1. `gradle wrapper --gradle-version 8.14.3` (if wrapper scripts are absent)
2. `./gradlew build`
3. JAR output: `build/libs/`

## GitHub cloud build
The `.github/workflows/build.yml` workflow runs Gradle on a hosted Java 21 runner. Upload the extracted project files to a GitHub repository, then open Actions → Build Eclipse Client → Run workflow. Download the artifact named `EclipseClient-JAR` from the completed run.

## Commands
- `.help`
- `.modules`
- `.toggle Sprint`
- `.bind Sprint G`
- `.schematic load example`
- `.printer start`
- `.printer stop`
- `.save`

Only use client modifications where allowed by the server's rules.


## Donut SMP / PvP additions
- Player ESP: visible player outline boxes and a nearby-player distance list (does not reveal players through solid blocks).
- Target HUD: nearest player health and distance.
- Coordinates: XYZ and dimension overlay.
- Armor Status: durability overlay for armor pieces.
- The click GUI keeps the purple/cyan Eclipse styling and these modules appear under Render and Combat.

This source archive has not been compiled in this environment. Run the GitHub Actions build and share the first Gradle error if compilation fails. Server rules vary; use visual/PvP features only where permitted.


## Eclipse Client 0.1 — through-wall ESP update
Player ESP now applies Minecraft's client-side glowing outline to nearby living players, which is visible through blocks, and restores each player's previous glowing state when the module is disabled or the world unloads. This can violate Donut SMP/server rules and may be blocked or patched by the server. The project has not been compiled or tested here; run the GitHub Actions build to check the exact Minecraft/Fabric API compatibility.
