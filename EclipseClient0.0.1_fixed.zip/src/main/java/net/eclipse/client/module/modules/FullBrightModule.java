package net.eclipse.client.module.modules;
import net.eclipse.client.module.*;
import net.minecraft.client.MinecraftClient;
public final class FullBrightModule extends Module {
    private double oldGamma;
    public FullBrightModule() { super("FullBright","Raises client gamma",Category.RENDER); }
    @Override public void onEnable() { var o=MinecraftClient.getInstance().options; oldGamma=o.getGamma().getValue(); o.getGamma().setValue(16.0); }
    @Override public void onDisable() { MinecraftClient.getInstance().options.getGamma().setValue(oldGamma); }
}
