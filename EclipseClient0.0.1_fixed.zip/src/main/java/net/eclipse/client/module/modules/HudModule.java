package net.eclipse.client.module.modules;
import net.eclipse.client.EclipseClient;
import net.eclipse.client.module.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
public final class HudModule extends Module {
    public HudModule() { super("HUD","Eclipse watermark and enabled module list",Category.RENDER); }
    @Override public void onHud(DrawContext ctx) {
        var mc=MinecraftClient.getInstance();
        ctx.drawTextWithShadow(mc.textRenderer,"Eclipse Client",8,8,0xFFB58CFF);
        int y=20;
        for (Module m:EclipseClient.MODULES.enabled().stream().filter(m->m!=this).sorted((a,b)->Integer.compare(mc.textRenderer.getWidth(b.name()),mc.textRenderer.getWidth(a.name()))).toList()) {
            ctx.drawTextWithShadow(mc.textRenderer,m.name(),8,y,0xFFFFFFFF); y+=11;
        }
    }
}
