package net.eclipse.client.module.modules;
import net.eclipse.client.module.*;
import net.minecraft.client.MinecraftClient;
public final class SprintModule extends Module {
    public SprintModule() { super("Sprint","Sprint while moving forward",Category.MOVEMENT); }
    @Override public void onTick(MinecraftClient c) {
        if (c.player!=null && c.options!=null) c.player.setSprinting(c.options.forwardKey.isPressed() && !c.player.isSneaking());
    }
}
