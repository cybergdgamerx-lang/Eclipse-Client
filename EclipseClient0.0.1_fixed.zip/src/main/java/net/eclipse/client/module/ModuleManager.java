package net.eclipse.client.module;

import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<Integer, Long> keyDebounce = new HashMap<>();
    public void register(Module m) { modules.add(m); }
    public List<Module> all() { return List.copyOf(modules); }
    public List<Module> in(Category category) { return modules.stream().filter(m -> m.category()==category).toList(); }
    public List<Module> enabled() { return modules.stream().filter(Module::enabled).collect(Collectors.toList()); }
    public Optional<Module> find(String name) { return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst(); }
    public void tick(MinecraftClient client) { for (Module m : modules) if (m.enabled()) m.onTick(client); }
    public void renderHud(DrawContext ctx) { for (Module m : modules) if (m.enabled()) m.onHud(ctx); }
    public void handleKeys(MinecraftClient client) {
        if (client.currentScreen != null) return;
        for (Module m : modules) {
            int key=m.keyCode();
            if (key!=-1 && org.lwjgl.glfw.GLFW.glfwGetKey(client.getWindow().getHandle(), key)==org.lwjgl.glfw.GLFW.GLFW_PRESS) {
                long now=System.currentTimeMillis();
                if (now-keyDebounce.getOrDefault(key,0L)>250) { m.toggle(); keyDebounce.put(key,now); }
            }
        }
    }
}
