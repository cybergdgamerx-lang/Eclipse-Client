package net.eclipse.client.module.modules;

import net.eclipse.client.module.Category;
import net.eclipse.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;

public final class TargetHUDModule extends Module {
    public TargetHUDModule() {
        super("Target HUD", "Show nearest player health and distance", Category.COMBAT);
    }

    @Override
    public void onHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        PlayerEntity target = null;
        double best = 12.0 * 12.0;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive() || player.isSpectator()) continue;
            double d = mc.player.squaredDistanceTo(player);
            if (d < best) { best = d; target = player; }
        }
        if (target == null) return;

        int x = Math.max(8, mc.getWindow().getScaledWidth() / 2 + 12);
        int y = Math.max(8, mc.getWindow().getScaledHeight() / 2 + 20);
        int w = 150;
        ctx.fill(x, y, x + w, y + 48, 0xE9101320);
        ctx.fill(x, y, x + w, y + 2, 0xFFB58CFF);
        ctx.drawTextWithShadow(mc.textRenderer, target.getName().getString(), x + 8, y + 8, 0xFFFFFFFF);
        float health = Math.max(0, target.getHealth());
        float max = Math.max(1, target.getMaxHealth());
        int barW = (int) ((w - 16) * Math.min(1, health / max));
        ctx.fill(x + 8, y + 22, x + w - 8, y + 28, 0xFF34394B);
        ctx.fill(x + 8, y + 22, x + 8 + barW, y + 28, health <= 6 ? 0xFFFF6666 : 0xFF68DDA4);
        String stats = String.format(java.util.Locale.ROOT, "%.1f HP  •  %.1fm",
                health, Math.sqrt(best));
        ctx.drawTextWithShadow(mc.textRenderer, stats, x + 8, y + 34, 0xFFBEC6D9);
    }
}
