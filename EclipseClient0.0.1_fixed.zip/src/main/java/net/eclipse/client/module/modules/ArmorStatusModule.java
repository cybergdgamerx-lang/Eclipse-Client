package net.eclipse.client.module.modules;

import net.eclipse.client.module.Category;
import net.eclipse.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public final class ArmorStatusModule extends Module {
    public ArmorStatusModule() {
        super("Armor Status", "Show armor durability for PvP", Category.COMBAT);
    }

    @Override
    public void onHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int x = 8;
        int y = mc.getWindow().getScaledHeight() - 78;
        ctx.fill(x - 3, y - 4, x + 108, y + 68, 0xB9101320);
        ctx.drawTextWithShadow(mc.textRenderer, "ARMOR", x + 3, y, 0xFFB58CFF);
        int row = 0;
        for (ItemStack stack : mc.player.getInventory().armor) {
            int yy = y + 13 + row * 12;
            String label = stack.isEmpty() ? "Empty" : stack.getName().getString();
            String durability = stack.isEmpty() ? "--" :
                    (stack.getMaxDamage() - stack.getDamage()) + "/" + stack.getMaxDamage();
            int color = 0xFFE7EAF5;
            if (!stack.isEmpty()) {
                double pct = (double)(stack.getMaxDamage() - stack.getDamage()) / Math.max(1, stack.getMaxDamage());
                if (pct < 0.2) color = 0xFFFF7777;
                else if (pct < 0.5) color = 0xFFFFD479;
            }
            if (label.length() > 12) label = label.substring(0, 10) + "..";
            ctx.drawTextWithShadow(mc.textRenderer, label, x + 3, yy, 0xFFBEC6D9);
            ctx.drawTextWithShadow(mc.textRenderer, durability, x + 72, yy, color);
            row++;
        }
    }
}
