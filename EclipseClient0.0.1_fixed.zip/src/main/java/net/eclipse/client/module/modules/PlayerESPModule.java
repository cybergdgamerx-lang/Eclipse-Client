package net.eclipse.client.module.modules;

import net.eclipse.client.module.Category;
import net.eclipse.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Visible player outline ESP. It intentionally draws visible outlines only;
 * it does not disable depth testing or reveal players through solid blocks.
 */
public final class PlayerESPModule extends Module {
    // Track only entities whose glowing state we changed, so disabling ESP restores them.
    private static final Map<UUID, Boolean> ORIGINAL_GLOW = new HashMap<>();
    public PlayerESPModule() {
        super("Player ESP", "Through-wall glowing outline plus nearby player distances", Category.RENDER);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            restoreGlow(mc);
            return;
        }
        for (PlayerEntity target : mc.world.getPlayers()) {
            if (target == mc.player || target.isSpectator() || !target.isAlive()) continue;
            if (mc.player.squaredDistanceTo(target) > 64.0 * 64.0) continue;
            ORIGINAL_GLOW.putIfAbsent(target.getUuid(), target.isGlowing());
            // Client-side glowing outline is rendered through blocks by Minecraft.
            target.setGlowing(true);
        }
    }

    @Override
    public void onDisable() {
        restoreGlow(MinecraftClient.getInstance());
    }

    private static void restoreGlow(MinecraftClient mc) {
        if (mc.world != null) {
            for (PlayerEntity player : mc.world.getPlayers()) {
                Boolean wasGlowing = ORIGINAL_GLOW.get(player.getUuid());
                if (wasGlowing != null) player.setGlowing(wasGlowing);
            }
        }
        ORIGINAL_GLOW.clear();
    }

    public static void registerWorldRenderHook() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null) return;
            if (!net.eclipse.client.EclipseClient.MODULES.find("Player ESP").map(Module::enabled).orElse(false)) return;

            MatrixStack matrices = context.matrixStack();
            VertexConsumerProvider consumers = context.consumers();
            if (matrices == null || consumers == null) return;
            Vec3d cameraPos = context.camera().getPos();

            for (PlayerEntity target : mc.world.getPlayers()) {
                if (target == mc.player || target.isSpectator() || !target.isAlive()) continue;
                if (mc.player.squaredDistanceTo(target) > 64.0 * 64.0) continue;
                Box box = target.getBoundingBox().expand(0.04)
                        .offset(-cameraPos.x, -cameraPos.y, -cameraPos.z);
                float healthRatio = Math.max(0.0f, Math.min(1.0f, target.getHealth() / Math.max(1.0f, target.getMaxHealth())));
                float red = 1.0f - healthRatio * 0.65f;
                float green = 0.35f + healthRatio * 0.65f;
                WorldRenderer.drawBox(matrices, consumers.getBuffer(RenderLayer.getLines()),
                        box, red, green, 0.95f, 0.95f);
            }
        });
    }

    @Override
    public void onHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        int x = 8;
        int y = 56;
        int shown = 0;
        ctx.drawTextWithShadow(mc.textRenderer, "PLAYER ESP", x, y, 0xFFB58CFF);
        y += 12;
        for (PlayerEntity target : mc.world.getPlayers()) {
            if (target == mc.player || !target.isAlive()) continue;
            double distance = Math.sqrt(mc.player.squaredDistanceTo(target));
            if (distance > 64) continue;
            String line = target.getName().getString() + "  " + String.format(java.util.Locale.ROOT, "%.1fm", distance);
            int color = target.getHealth() <= 6 ? 0xFFFF7777 : 0xFFE7EAF5;
            ctx.drawTextWithShadow(mc.textRenderer, line, x, y, color);
            y += 11;
            if (++shown >= 6) break;
        }
    }
}
