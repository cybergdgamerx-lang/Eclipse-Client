package net.eclipse.client.module;

import java.util.*;
import net.eclipse.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class Module {
    private final String name, description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int keyCode = -1;
    protected Module(String name, String description, Category category) {
        this.name=name; this.description=description; this.category=category;
    }
    public String name() { return name; } public String description() { return description; }
    public Category category() { return category; } public boolean enabled() { return enabled; }
    public int keyCode() { return keyCode; } public void setKeyCode(int key) { keyCode=key; }
    public List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    protected <T extends Setting<?>> T add(T setting) { settings.add(setting); return setting; }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean state) {
        if (enabled==state) return;
        enabled=state;
        if (state) onEnable(); else onDisable();
    }
    public void onEnable() {} public void onDisable() {}
    public void onTick(MinecraftClient client) {}
    public void onHud(DrawContext ctx) {}
}
