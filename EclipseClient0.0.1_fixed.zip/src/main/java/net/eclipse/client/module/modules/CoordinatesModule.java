package net.eclipse.client.module.modules;

import net.eclipse.client.module.Category;
import net.eclipse.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class CoordinatesModule extends Module {
    public CoordinatesModule() {
        super("Coordinates", "Show XYZ and dimension", Category.RENDER);
    }

    @Override
    public void onHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        String coords = String.format(java.util.Locale.ROOT, "XYZ  %d  %d  %d",
                (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ());
        String dimension = mc.world.getRegistryKey().getValue().getPath().toUpperCase(java.util.Locale.ROOT);
        int y = mc.getWindow().getScaledHeight() - 28;
        ctx.fill(6, y - 3, 165, y + 22, 0xB9101320);
        ctx.drawTextWithShadow(mc.textRenderer, coords, 11, y, 0xFFE8EAF4);
        ctx.drawTextWithShadow(mc.textRenderer, dimension, 11, y + 11, 0xFFB58CFF);
    }
}
