package net.eclipse.client.module.modules;

import net.eclipse.client.module.*;
import net.eclipse.client.schematic.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

/**
 * Conservative printer planner: scans loaded target positions and queues missing blocks.
 * Actual placement is deliberately manual-confirmation gated; multiplayer automation may violate server rules.
 */
public final class PrinterModule extends Module {
    private final NumberSettingProxy reach = new NumberSettingProxy(4.5);
    private final PrinterEngine engine = new PrinterEngine();
    public PrinterModule() { super("AutoPrinter","Plan schematic placements from a loaded schematic",Category.BUILDER); }
    public PrinterEngine engine() { return engine; }
    @Override public void onTick(MinecraftClient client) {
        if (client.player==null || client.world==null || !engine.loaded()) return;
        engine.scan(client, reach.value());
    }
    private record NumberSettingProxy(double value) {}
}
