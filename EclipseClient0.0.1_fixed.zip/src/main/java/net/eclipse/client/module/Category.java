package net.eclipse.client.module;
public enum Category { COMBAT, MOVEMENT, RENDER, PLAYER, WORLD, BUILDER, MISC }
