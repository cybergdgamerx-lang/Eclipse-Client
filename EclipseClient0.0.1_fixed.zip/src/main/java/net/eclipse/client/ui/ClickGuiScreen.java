package net.eclipse.client.ui;

import net.eclipse.client.EclipseClient;
import net.eclipse.client.module.Category;
import net.eclipse.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Eclipse Client click GUI.
 * Draws a compact dark interface with a category sidebar, module cards,
 * enabled indicators, hover states, and mouse-wheel scrolling.
 */
public final class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 470;
    private static final int PANEL_H = 330;
    private static final int SIDEBAR_W = 118;
    private static final int HEADER_H = 48;
    private static final int CARD_H = 48;
    private static final int CARD_GAP = 7;

    private Category selectedCategory = Category.RENDER;
    private int scrollOffset = 0;

    private int panelX() { return Math.max(8, (width - PANEL_W) / 2); }
    private int panelY() { return Math.max(8, (height - PANEL_H) / 2); }

    public ClickGuiScreen() {
        super(Text.literal("Eclipse Client"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);

        int x = panelX();
        int y = panelY();
        int right = x + PANEL_W;
        int bottom = y + PANEL_H;

        // Main panel and top accent.
        ctx.fill(x - 1, y - 1, right + 1, bottom + 1, 0xFF070910);
        ctx.fill(x, y, right, bottom, 0xFF10131D);
        ctx.fill(x, y, right, y + 3, 0xFF9D68FF);
        ctx.fill(x, y + 3, x + PANEL_W / 2, y + 5, 0xFF55D6FF);

        // Header.
        ctx.fill(x, y + 5, right, y + HEADER_H, 0xFF171B29);
        ctx.drawTextWithShadow(textRenderer, "ECLIPSE", x + 15, y + 14, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "CLIENT", x + 15 + textRenderer.getWidth("ECLIPSE") + 5,
                y + 14, 0xFFAD82FF);
        ctx.drawTextWithShadow(textRenderer, "DONUT SMP READY  •  RIGHT SHIFT",
                x + 15, y + 29, 0xFF8B94AB);

        int enabledCount = EclipseClient.MODULES.enabled().size();
        String status = enabledCount + " ON";
        ctx.fill(right - 75, y + 14, right - 15, y + 34, 0xFF252A3A);
        ctx.drawTextWithShadow(textRenderer, status,
                right - 45 - textRenderer.getWidth(status) / 2, y + 20, 0xFF70E7B1);

        // Sidebar.
        int sideTop = y + HEADER_H;
        ctx.fill(x, sideTop, x + SIDEBAR_W, bottom - 27, 0xFF131724);
        ctx.drawTextWithShadow(textRenderer, "CATEGORIES", x + 12, sideTop + 12, 0xFF707C96);

        Category[] categories = Category.values();
        int categoryY = sideTop + 31;
        for (Category category : categories) {
            boolean selected = category == selectedCategory;
            int rowTop = categoryY;
            int rowBottom = rowTop + 25;
            if (selected) {
                ctx.fill(x + 7, rowTop, x + SIDEBAR_W - 7, rowBottom, 0xFF34264F);
                ctx.fill(x + 7, rowTop + 4, x + 10, rowBottom - 4, 0xFFB18AFF);
            } else if (inside(mouseX, mouseY, x + 7, rowTop, x + SIDEBAR_W - 7, rowBottom)) {
                ctx.fill(x + 7, rowTop, x + SIDEBAR_W - 7, rowBottom, 0xFF202637);
            }
            String label = titleCase(category.name());
            ctx.drawTextWithShadow(textRenderer, label, x + 17, rowTop + 8,
                    selected ? 0xFFDCCBFF : 0xFFADB5C8);
            categoryY += 29;
        }

        // Content area.
        int contentX = x + SIDEBAR_W + 14;
        int contentRight = right - 14;
        int contentTop = sideTop + 13;
        int contentBottom = bottom - 34;
        ctx.drawTextWithShadow(textRenderer, titleCase(selectedCategory.name()),
                contentX, contentTop, 0xFFFFFFFF);
        String subtitle = "Click a card to toggle a module";
        ctx.drawTextWithShadow(textRenderer, subtitle, contentX, contentTop + 13, 0xFF858FA6);

        // Clip visually by drawing only cards that intersect the content viewport.
        int listTop = contentTop + 32;
        int listBottom = contentBottom;
        List<Module> modules = new ArrayList<>(EclipseClient.MODULES.in(selectedCategory));
        int maxScroll = Math.max(0, modules.size() * (CARD_H + CARD_GAP) - CARD_GAP - (listBottom - listTop));
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));

        for (int i = 0; i < modules.size(); i++) {
            Module module = modules.get(i);
            int cardY = listTop + i * (CARD_H + CARD_GAP) - scrollOffset;
            if (cardY + CARD_H < listTop || cardY > listBottom) continue;

            boolean hovered = inside(mouseX, mouseY, contentX, cardY, contentRight, cardY + CARD_H)
                    && mouseY >= listTop && mouseY <= listBottom;
            int cardColor = module.enabled()
                    ? (hovered ? 0xFF30274A : 0xFF252039)
                    : (hovered ? 0xFF252B3B : 0xFF1A1F2C);
            ctx.fill(contentX, cardY, contentRight, cardY + CARD_H, cardColor);
            ctx.fill(contentX, cardY, contentX + 3, cardY + CARD_H,
                    module.enabled() ? 0xFFB18AFF : 0xFF343B4E);

            ctx.drawTextWithShadow(textRenderer, module.name(), contentX + 11, cardY + 8,
                    module.enabled() ? 0xFFE8DFFF : 0xFFE0E4EF);
            String description = module.description();
            if (description != null && !description.isBlank()) {
                int maxWidth = contentRight - contentX - 76;
                while (textRenderer.getWidth(description) > maxWidth && description.length() > 4) {
                    description = description.substring(0, description.length() - 4) + "...";
                }
                ctx.drawTextWithShadow(textRenderer, description, contentX + 11, cardY + 25, 0xFF8993AA);
            }

            String toggle = module.enabled() ? "ON" : "OFF";
            int pillColor = module.enabled() ? 0xFF285744 : 0xFF303647;
            ctx.fill(contentRight - 47, cardY + 14, contentRight - 10, cardY + 33, pillColor);
            ctx.drawTextWithShadow(textRenderer, toggle,
                    contentRight - 28 - textRenderer.getWidth(toggle) / 2,
                    cardY + 20, module.enabled() ? 0xFF8BF0C0 : 0xFFB3BDCF);
        }

        if (modules.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, "Nothing here yet.",
                    contentX, listTop + 12, 0xFF858FA6);
        } else if (maxScroll > 0) {
            String scrollHint = "SCROLL FOR MORE";
            ctx.drawTextWithShadow(textRenderer, scrollHint,
                    contentRight - textRenderer.getWidth(scrollHint), bottom - 45, 0xFF6E7890);
        }

        // Footer.
        ctx.fill(x, bottom - 27, right, bottom, 0xFF171B29);
        ctx.drawTextWithShadow(textRenderer, "ECLIPSE  •  PVP / VISUALS / UTILITY",
                x + 12, bottom - 18, 0xFF7F8AA2);
        ctx.drawTextWithShadow(textRenderer, "ESC  CLOSE",
                right - 72, bottom - 18, 0xFFB6BED0);

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int x = panelX();
        int y = panelY();
        int sideTop = y + HEADER_H;
        int categoryY = sideTop + 31;

        for (Category category : Category.values()) {
            int rowTop = categoryY;
            int rowBottom = rowTop + 25;
            if (inside(mouseX, mouseY, x + 7, rowTop, x + SIDEBAR_W - 7, rowBottom)) {
                if (selectedCategory != category) {
                    selectedCategory = category;
                    scrollOffset = 0;
                }
                return true;
            }
            categoryY += 29;
        }

        int contentX = x + SIDEBAR_W + 14;
        int contentRight = x + PANEL_W - 14;
        int contentTop = sideTop + 13;
        int listTop = contentTop + 32;
        int listBottom = y + PANEL_H - 34;
        if (mouseX >= contentX && mouseX <= contentRight && mouseY >= listTop && mouseY <= listBottom) {
            List<Module> modules = EclipseClient.MODULES.in(selectedCategory);
            for (int i = 0; i < modules.size(); i++) {
                int cardY = listTop + i * (CARD_H + CARD_GAP) - scrollOffset;
                if (inside(mouseX, mouseY, contentX, cardY, contentRight, cardY + CARD_H)) {
                    modules.get(i).toggle();
                    EclipseClient.CONFIG.save();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int x = panelX();
        int y = panelY();
        int contentX = x + SIDEBAR_W + 14;
        int contentRight = x + PANEL_W - 14;
        int listTop = y + HEADER_H + 13 + 32;
        int listBottom = y + PANEL_H - 34;
        if (inside(mouseX, mouseY, contentX, listTop, contentRight, listBottom)) {
            scrollOffset -= (int) (verticalAmount * (CARD_H + CARD_GAP));
            int count = EclipseClient.MODULES.in(selectedCategory).size();
            int maxScroll = Math.max(0, count * (CARD_H + CARD_GAP) - CARD_GAP - (listBottom - listTop));
            scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static boolean inside(double mx, double my, int left, int top, int right, int bottom) {
        return mx >= left && mx <= right && my >= top && my <= bottom;
    }

    private static String titleCase(String value) {
        String lower = value.toLowerCase();
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }
}
