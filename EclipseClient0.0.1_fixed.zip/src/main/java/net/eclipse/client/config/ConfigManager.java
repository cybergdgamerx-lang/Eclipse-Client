package net.eclipse.client.config;
import com.google.gson.*;
import net.eclipse.client.EclipseClient;
import net.eclipse.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.io.IOException;
public final class ConfigManager {
    private final Path path=FabricLoader.getInstance().getConfigDir().resolve("eclipse.json");
    public void save(){
        JsonObject root=new JsonObject();
        for(Module m:EclipseClient.MODULES.all()){JsonObject o=new JsonObject();o.addProperty("enabled",m.enabled());o.addProperty("keyCode",m.keyCode());root.add(m.name(),o);}
        try{Files.createDirectories(path.getParent());Files.writeString(path,new GsonBuilder().setPrettyPrinting().create().toJson(root));}
        catch(IOException e){System.err.println("[Eclipse] Config save failed: "+e.getMessage());}
    }
    public void load(){
        if(!Files.exists(path)){save();return;}
        try{JsonObject root=JsonParser.parseString(Files.readString(path)).getAsJsonObject();for(Module m:EclipseClient.MODULES.all()){if(!root.has(m.name()))continue;JsonObject o=root.getAsJsonObject(m.name());if(o.has("keyCode"))m.setKeyCode(o.get("keyCode").getAsInt());if(o.has("enabled"))m.setEnabled(o.get("enabled").getAsBoolean());}}
        catch(Exception e){System.err.println("[Eclipse] Config load failed: "+e.getMessage());}
    }
}
