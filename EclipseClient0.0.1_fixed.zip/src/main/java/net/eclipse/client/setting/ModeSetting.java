package net.eclipse.client.setting;
import java.util.List;
public final class ModeSetting extends Setting<String> {
    private final List<String> modes;
    public ModeSetting(String name, String initial, List<String> modes) {
        super(name, initial); if (modes.isEmpty()) throw new IllegalArgumentException("modes empty");
        this.modes=List.copyOf(modes); set(initial);
    }
    @Override protected String validate(String value) {
        if (value == null || !modes.contains(value)) return modes.get(0);
        return value;
    }
    public List<String> modes() { return modes; }
}
