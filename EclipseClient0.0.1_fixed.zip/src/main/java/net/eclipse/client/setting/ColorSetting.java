package net.eclipse.client.setting;
public final class ColorSetting extends Setting<Integer> {
    public ColorSetting(String name, int rgba) { super(name, rgba); }
}
