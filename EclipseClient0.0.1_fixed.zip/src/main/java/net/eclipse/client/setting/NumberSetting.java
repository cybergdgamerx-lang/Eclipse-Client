package net.eclipse.client.setting;
public final class NumberSetting extends Setting<Double> {
    private final double min, max, step;
    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name, value); if (min > max || step <= 0) throw new IllegalArgumentException("Invalid range");
        this.min=min; this.max=max; this.step=step; set(value);
    }
    @Override protected Double validate(Double v) {
        if (v == null || !Double.isFinite(v)) return min;
        double clamped = Math.max(min, Math.min(max, v));
        return min + Math.round((clamped-min)/step)*step;
    }
    public double min() { return min; } public double max() { return max; } public double step() { return step; }
}
