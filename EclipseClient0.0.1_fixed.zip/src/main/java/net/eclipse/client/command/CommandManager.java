package net.eclipse.client.command;

import net.eclipse.client.EclipseClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import java.util.Locale;

public final class CommandManager {
    public void execute(String input) {
        var player=MinecraftClient.getInstance().player;
        if (player==null) return;
        String[] a=input.trim().split("\\s+");
        if (a.length==0 || a[0].isBlank()) return;
        switch(a[0].toLowerCase(Locale.ROOT)) {
            case "help" -> say(".bind <module> <key> | .toggle <module> | .modules | .schematic load <name> | .printer start/stop | .save");
            case "modules" -> say(String.join(", ",EclipseClient.MODULES.all().stream().map(m->m.name()+(m.enabled()?" [ON]":"")).toList()));
            case "toggle" -> { if(a.length<2){say("Usage: .toggle <module>");break;} var m=EclipseClient.MODULES.find(a[1]); if(m.isEmpty())say("Unknown module");else{m.get().toggle();say(m.get().name()+" "+(m.get().enabled()?"enabled":"disabled"));} }
            case "bind" -> { if(a.length<3){say("Usage: .bind <module> <GLFW_KEY_NAME|none>");break;} var m=EclipseClient.MODULES.find(a[1]); if(m.isEmpty()){say("Unknown module");break;} int key=key(a[2]); if(key==-2){say("Unknown key");break;} m.get().setKeyCode(key); EclipseClient.CONFIG.save(); say("Keybind saved."); }
            case "schematic" -> { if(a.length>=3 && a[1].equalsIgnoreCase("load")) say("Schematic reader is an extension point in this scaffold; native .schem/.litematic parsing is not implemented yet."); else say("Usage: .schematic load <name>"); }
            case "printer" -> { if(a.length>=2 && a[1].equalsIgnoreCase("start")){EclipseClient.MODULES.find("AutoPrinter").ifPresent(m->m.setEnabled(true));say("Printer planner enabled.");} else if(a.length>=2 && a[1].equalsIgnoreCase("stop")){EclipseClient.MODULES.find("AutoPrinter").ifPresent(m->m.setEnabled(false));say("Printer stopped.");} else say("Usage: .printer start|stop"); }
            case "save" -> { EclipseClient.CONFIG.save(); say("Saved."); }
            default -> say("Unknown command. Try .help");
        }
    }
    private int key(String s) {
        if(s.equalsIgnoreCase("none")) return -1;
        try{return org.lwjgl.glfw.GLFW.class.getField("GLFW_KEY_"+s.toUpperCase(Locale.ROOT)).getInt(null);}
        catch(ReflectiveOperationException e){return -2;}
    }
    private void say(String s){var p=MinecraftClient.getInstance().player;if(p!=null)p.sendMessage(Text.literal("§5[Eclipse] §r"+s),false);}
}
