package net.eclipse.client.schematic;
import java.util.List;
public record Schematic(String name, int width, int height, int length, List<SchematicBlock> blocks) {
    public Schematic { blocks=List.copyOf(blocks); }
}
