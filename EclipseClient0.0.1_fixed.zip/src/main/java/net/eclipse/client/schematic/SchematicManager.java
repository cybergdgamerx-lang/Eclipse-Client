package net.eclipse.client.schematic;

import java.io.IOException;
import java.nio.file.*;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Schematic storage and format dispatch. This initial version accepts a small JSON interchange format.
 * NBT-based Sponge .schem and Litematica .litematic readers are isolated behind this API and are TODO.
 * It never silently treats unsupported binary formats as valid schematics.
 */
public final class SchematicManager {
    private final Path directory=FabricLoader.getInstance().getConfigDir().resolve("eclipse/schematics");
    public Path directory() { try { Files.createDirectories(directory); } catch (IOException e) { throw new IllegalStateException(e); } return directory; }
    public Schematic load(String name) throws IOException {
        Path path=directory().resolve(name).normalize();
        if (!path.startsWith(directory())) throw new IOException("Invalid schematic path");
        if (!path.getFileName().toString().endsWith(".json")) throw new IOException("This build currently supports Eclipse JSON schematics only; .schem/.litematic readers are not implemented yet.");
        throw new IOException("JSON schematic decoder requires block registry resolution and is not yet implemented.");
    }
}
