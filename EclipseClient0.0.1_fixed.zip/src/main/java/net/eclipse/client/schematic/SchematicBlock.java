package net.eclipse.client.schematic;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
public record SchematicBlock(BlockPos relativePos, BlockState state) {}
