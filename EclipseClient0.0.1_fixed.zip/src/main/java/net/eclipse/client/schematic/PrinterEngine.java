package net.eclipse.client.schematic;

import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

/** Placement planning queue; intentionally does not send packets or bypass vanilla interaction checks. */
public final class PrinterEngine {
    private Schematic schematic;
    private BlockPos origin;
    private final Deque<SchematicBlock> queue=new ArrayDeque<>();
    private long lastScan;
    public boolean loaded() { return schematic!=null && origin!=null; }
    public void setSchematic(Schematic schematic, BlockPos origin) {
        this.schematic=Objects.requireNonNull(schematic); this.origin=Objects.requireNonNull(origin); queue.clear();
    }
    public void clear() { schematic=null; origin=null; queue.clear(); }
    public List<BlockPos> targets() {
        if (!loaded()) return List.of();
        return schematic.blocks().stream().map(b->origin.add(b.relativePos())).toList();
    }
    public int queued() { return queue.size(); }
    public Optional<SchematicBlock> next() { return Optional.ofNullable(queue.peekFirst()); }
    public void scan(MinecraftClient client, double reach) {
        if (!loaded() || client.player==null || client.world==null || System.currentTimeMillis()-lastScan<350) return;
        lastScan=System.currentTimeMillis(); queue.clear();
        for (SchematicBlock b:schematic.blocks()) {
            BlockPos target=origin.add(b.relativePos());
            if (client.player.getPos().distanceTo(target.toCenterPos())>reach) continue;
            if (client.world.isChunkLoaded(target) && !client.world.getBlockState(target).equals(b.state())) queue.addLast(b);
        }
    }
}
