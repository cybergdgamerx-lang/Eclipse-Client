package net.eclipse.client.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/** Annotation-driven, typed event dispatch. Register listener objects once at startup. */
public final class EventBus {
    private record Handler(Object owner, Class<?> eventType, Method method) {}
    private final List<Handler> handlers = new CopyOnWriteArrayList<>();

    public void register(Object listener) {
        for (Method method : listener.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(Subscribe.class)) continue;
            if (method.getParameterCount() != 1 ||
                !Event.class.isAssignableFrom(method.getParameterTypes()[0])) {
                throw new IllegalArgumentException("@Subscribe method must accept exactly one Event: " + method);
            }
            method.setAccessible(true);
            handlers.add(new Handler(listener, method.getParameterTypes()[0], method));
        }
    }
    public void unregister(Object listener) { handlers.removeIf(h -> h.owner() == listener); }
    public void post(Event event) {
        for (Handler h : handlers) {
            if (!h.eventType().isInstance(event)) continue;
            try { h.method().invoke(h.owner(), event); }
            catch (ReflectiveOperationException | RuntimeException e) {
                System.err.println("[Eclipse] Event handler failed: " + h.method().getName() + ": " + e.getMessage());
            }
        }
    }
}
