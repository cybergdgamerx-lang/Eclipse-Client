package net.eclipse.client.event.events;
import net.eclipse.client.event.Event;
import net.minecraft.client.MinecraftClient;
public sealed interface TickEvent extends Event permits TickEvent.Pre, TickEvent.Post {
    MinecraftClient client();
    record Pre(MinecraftClient client) implements TickEvent {}
    record Post(MinecraftClient client) implements TickEvent {}
}
