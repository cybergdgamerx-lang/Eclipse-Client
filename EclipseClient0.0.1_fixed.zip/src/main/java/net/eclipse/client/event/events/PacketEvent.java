package net.eclipse.client.event.events;
import net.eclipse.client.event.Event;
/** Packet hooks are exposed as an API contract; connect version-specific mixins before use. */
public sealed interface PacketEvent extends Event permits PacketEvent.Send, PacketEvent.Receive {
    Object packet();
    record Send(Object packet) implements PacketEvent {}
    record Receive(Object packet) implements PacketEvent {}
}
