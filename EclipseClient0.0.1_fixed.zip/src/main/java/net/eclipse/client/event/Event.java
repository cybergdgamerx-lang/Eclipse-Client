package net.eclipse.client.event;
public interface Event {}
