package net.eclipse.client.event.events;
import net.eclipse.client.event.Event;
import net.minecraft.client.render.WorldRenderContext;
public record Render3DEvent(WorldRenderContext context) implements Event {}
