package net.eclipse.client.event.events;
import net.eclipse.client.event.Event;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
public record BlockPlaceEvent(BlockPos pos, BlockState state, boolean accepted) implements Event {}
