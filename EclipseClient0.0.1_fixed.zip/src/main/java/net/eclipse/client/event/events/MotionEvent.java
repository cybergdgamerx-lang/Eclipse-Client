package net.eclipse.client.event.events;
import net.eclipse.client.event.Event;
public record MotionEvent(double x, double y, double z, float yaw, float pitch, Phase phase) implements Event {
    public enum Phase { PRE, POST }
}
