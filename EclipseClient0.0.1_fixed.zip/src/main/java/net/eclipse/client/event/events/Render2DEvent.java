package net.eclipse.client.event.events;
import net.eclipse.client.event.Event;
import net.minecraft.client.gui.DrawContext;
public record Render2DEvent(DrawContext context, float tickDelta) implements Event {}
