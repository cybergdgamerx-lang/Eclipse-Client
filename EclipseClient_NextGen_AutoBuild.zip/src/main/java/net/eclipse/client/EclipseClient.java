package net.eclipse.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.eclipse.client.command.CommandManager;
import net.eclipse.client.config.ConfigManager;
import net.eclipse.client.event.EventBus;
import net.eclipse.client.event.events.TickEvent;
import net.eclipse.client.module.ModuleManager;
import net.eclipse.client.module.modules.*;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class EclipseClient implements ClientModInitializer {
    public static final String ID = "eclipse";
    public static final String PREFIX = ".";
    public static final EventBus EVENTS = new EventBus();
    public static final ModuleManager MODULES = new ModuleManager();
    public static final CommandManager COMMANDS = new CommandManager();
    public static final ConfigManager CONFIG = new ConfigManager();
    private KeyBinding clickGuiKey;

    @Override public void onInitializeClient() {
        MODULES.register(new SprintModule());
        MODULES.register(new FullBrightModule());
        MODULES.register(new HudModule());
        MODULES.register(new PrinterModule());
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.eclipse.click_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC));
        CONFIG.load();
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            EVENTS.post(new TickEvent.Pre(client));
            MODULES.handleKeys(client);
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MODULES.tick(client);
            EVENTS.post(new TickEvent.Post(client));
            while (clickGuiKey.wasPressed()) client.setScreen(new net.eclipse.client.ui.ClickGuiScreen());
        });
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!message.startsWith(PREFIX)) return true;
            COMMANDS.execute(message.substring(PREFIX.length()));
            return false;
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> MODULES.renderHud(drawContext));
    }
}
