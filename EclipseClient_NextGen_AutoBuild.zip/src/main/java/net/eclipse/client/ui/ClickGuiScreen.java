package net.eclipse.client.ui;
import net.eclipse.client.EclipseClient;
import net.eclipse.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
public final class ClickGuiScreen extends Screen {
    public ClickGuiScreen(){super(Text.literal("Eclipse Client"));}
    @Override public void render(DrawContext c,int mx,int my,float d){
        renderBackground(c,mx,my,d);int x=Math.max(8,width/2-135),y=22;
        c.fill(x,y,x+270,y+25,0xFF261B3D);c.drawTextWithShadow(textRenderer,"Eclipse Client  •  click modules to toggle",x+8,y+8,0xFFB58CFF);y+=32;
        for(Module m:EclipseClient.MODULES.all()){c.fill(x,y,x+270,y+20,m.enabled()?0xFF554080:0xDD171720);c.drawTextWithShadow(textRenderer,m.name()+"  ["+m.category()+"]",x+8,y+6,0xFFFFFFFF);y+=22;}
        super.render(c,mx,my,d);
    }
    @Override public boolean mouseClicked(double mx,double my,int button){
        if(button==0){int x=Math.max(8,width/2-135),y=54;for(Module m:EclipseClient.MODULES.all()){if(mx>=x&&mx<=x+270&&my>=y&&my<=y+20){m.toggle();EclipseClient.CONFIG.save();return true;}y+=22;}}
        return super.mouseClicked(mx,my,button);
    }
    @Override public boolean keyPressed(int key,int scan,int mods){if(key==GLFW.GLFW_KEY_ESCAPE){close();return true;}return super.keyPressed(key,scan,mods);}
    @Override public boolean shouldPause(){return false;}
}
